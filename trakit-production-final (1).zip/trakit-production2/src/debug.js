// Temporary debug - remove after fixing
export const debugEnv = () => {
  console.log("PAYSTACK KEY:", process.env.REACT_APP_PAYSTACK_PUBLIC_KEY ? "✅ Found" : "❌ Missing");
  console.log("SUPABASE URL:", process.env.REACT_APP_SUPABASE_URL ? "✅ Found" : "❌ Missing");
  console.log("SUPABASE KEY:", process.env.REACT_APP_SUPABASE_ANON_KEY ? "✅ Found" : "❌ Missing");
};
